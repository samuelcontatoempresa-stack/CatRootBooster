package com.catroot.booster
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.View

class CrosshairView(c:Context):View(c) {
    enum class Shape { DOT, CROSS, CIRCLE }
    var shape=Shape.CROSS
    var sizePx=30f
    var opacity=0.9f
    var color=Color.CYAN
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas); p.color=color; p.alpha=(opacity.coerceIn(.1f,1f)*255).toInt()
        p.strokeWidth=3f; val x=width/2f; val y=height/2f
        when(shape) {
            Shape.DOT -> { p.style=Paint.Style.FILL; canvas.drawCircle(x,y,sizePx/7,p) }
            Shape.CROSS -> { p.style=Paint.Style.STROKE; canvas.drawLine(x-sizePx,y,x+sizePx,y,p); canvas.drawLine(x,y-sizePx,x,y+sizePx,p) }
            Shape.CIRCLE -> { p.style=Paint.Style.STROKE; canvas.drawCircle(x,y,sizePx,p) }
        }
    }
}
