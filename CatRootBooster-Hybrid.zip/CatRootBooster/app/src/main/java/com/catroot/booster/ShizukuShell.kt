package com.catroot.booster

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Parcel
import rikka.shizuku.Shizuku

/** UserService Shizuku para executar somente os comandos de sistema necessários ao app. */
class ShizukuShell(private val context: Context) {
    @Volatile private var remote: IBinder? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) { remote = service }
        override fun onServiceDisconnected(name: ComponentName?) { remote = null }
    }

    fun permitted(): Boolean = Shizuku.pingBinder() &&
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED

    fun request() {
        if (Shizuku.pingBinder() && !permitted()) Shizuku.requestPermission(2026)
    }

    @Synchronized
    fun connect(): Boolean {
        if (remote?.isBinderAlive == true) return true
        check(Shizuku.pingBinder()) { "Inicie o Shizuku antes de continuar." }
        check(permitted()) { "Conceda a permissão do CatRoot Booster no Shizuku." }
        val args = Shizuku.UserServiceArgs(ComponentName(context, ShizukuCommandService::class.java))
            .daemon(false)
            .processNameSuffix("catroot_shell")
            .tag("catroot-system-commands")
            .version(2)
        Shizuku.bindUserService(args, connection)
        repeat(100) {
            if (remote?.isBinderAlive == true) return true
            Thread.sleep(50)
        }
        return remote?.isBinderAlive == true
    }

    fun run(command: String): String {
        check(permitted()) { "Conceda a permissão do Shizuku." }
        check(connect()) { "Serviço Shizuku indisponível." }
        check(isAllowed(command)) { "Comando não permitido." }
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(ShizukuCommandService.DESCRIPTOR)
            data.writeString(command)
            check(remote!!.transact(1, data, reply, 0)) { "Falha na comunicação com o serviço Shizuku." }
            reply.readException()
            return reply.readString().orEmpty()
        } finally {
            data.recycle(); reply.recycle()
        }
    }

    private fun isAllowed(command: String): Boolean =
        command == "wm size reset" || command == "wm density reset" ||
        command == "wm size" || command == "wm density" ||
        Regex("wm size [1-9][0-9]{2,4}x[1-9][0-9]{2,4}").matches(command) ||
        Regex("wm density [1-9][0-9]{1,3}").matches(command) ||
        Regex("settings put system (peak_refresh_rate|min_refresh_rate) (60|90|120|144)(\\.0)?").matches(command)
}
