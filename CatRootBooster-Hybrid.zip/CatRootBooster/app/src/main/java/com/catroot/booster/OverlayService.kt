package com.catroot.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var hudLabel: TextView? = null
    private var crosshair: CrosshairView? = null

    override fun onCreate() {
        super.onCreate()
        val channelId = "cat_hud"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, getString(R.string.channel_hud), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("CAT ROOT HUD ativo")
            .setContentText("O painel flutuante está habilitado.")
            .setOngoing(true)
            .build()
        startForeground(41, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        removeViews()
        windowManager = getSystemService(WindowManager::class.java)
        val snapshot = runCatching { DeviceInfo.read(this) }.getOrNull()
        val label = TextView(this).apply {
            text = if (snapshot != null) "CAT ROOT HUD  •  RAM LIVRE ${snapshot.ramFree} MB  •  ${snapshot.batteryTemp} °C" else "CAT ROOT  •  HUD ATIVO"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(14, 9, 14, 9)
            setBackgroundColor(0xDD201634.toInt())
        }
        hudLabel = label
        val overlayType = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val labelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 14; y = 110 }
        runCatching { windowManager?.addView(label, labelParams) }

        val color = runCatching { Color.parseColor(intent?.getStringExtra("crosshair_color") ?: "#70F4FF") }.getOrDefault(Color.CYAN)
        val size = (intent?.getIntExtra("crosshair_size", 54) ?: 54).coerceIn(12, 100)
        val aim = CrosshairView(this).apply { this.color = color; sizePx = size.toFloat(); opacity = .85f }
        crosshair = aim
        val crossParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        runCatching { windowManager?.addView(aim, crossParams) }
        return START_STICKY
    }

    private fun removeViews() {
        hudLabel?.let { runCatching { windowManager?.removeView(it) } }
        crosshair?.let { runCatching { windowManager?.removeView(it) } }
        hudLabel = null; crosshair = null
    }

    override fun onDestroy() { removeViews(); windowManager = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
