package com.catroot.booster
import android.app.Activity
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class GameLauncherActivity:Activity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20);setBackgroundColor(0xFF08080C.toInt()) }
        val title=TextView(this).apply { text="JOGOS INSTALADOS";textSize=22f;setTextColor(-1);gravity=Gravity.CENTER }
        list.addView(title)
        val games=packageManager.getInstalledApplications(0).filter {
            android.os.Build.VERSION.SDK_INT>=26 && it.category==ApplicationInfo.CATEGORY_GAME && packageManager.getLaunchIntentForPackage(it.packageName)!=null
        }.sortedBy { packageManager.getApplicationLabel(it).toString() }
        games.forEach { app ->
            val row=TextView(this).apply {
                text="🎮  ${packageManager.getApplicationLabel(app)}";textSize=17f;setTextColor(-1);setPadding(12,18,12,18)
                setOnClickListener { packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } }
            }
            list.addView(row)
        }
        setContentView(list)
    }
}
