package com.apexpulse.tuner

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.apexpulse.tuner.data.*
import com.apexpulse.tuner.system.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LaboratoryPage(currentDpi: Int, onDpi: (Int) -> Unit, currentHz: Int, onHz: (Int) -> Unit, currentResolution: String, initialNote: String, onNoteSave: (String) -> Unit, onResolution: (Int, Int) -> Unit) {
    var baseDpi by remember { mutableIntStateOf(currentDpi.coerceAtLeast(240)) }
    var targetDpi by remember { mutableIntStateOf(480) }
    var sensitivity by remember { mutableFloatStateOf(100f) }
    var fingers by remember { mutableIntStateOf(4) }
    var pointers by remember { mutableIntStateOf(0) }
    var note by remember(initialNote) { mutableStateOf(initialNote) }
    val aspectRatio = remember(currentResolution) { Regex("([0-9]+)\\s*[×x]\\s*([0-9]+)").find(currentResolution)?.let { it.groupValues[1].toFloat() / it.groupValues[2].toFloat() } ?: (9f / 20f) }
    val suggestion = SensitivityLab.convert(sensitivity, baseDpi, targetDpi)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Conversor de sensibilidade por DPI") {
            Text("Escala proporcional estimada. Cada jogo pode usar curvas, limites e aceleração próprios.", color = Color.LightGray, fontSize = 12.sp)
            Text("DPI de origem: $baseDpi"); Slider(baseDpi.toFloat(), { baseDpi = it.toInt() }, valueRange = 240f..640f, steps = 39)
            Text("Novo DPI: $targetDpi"); Slider(targetDpi.toFloat(), { targetDpi = it.toInt() }, valueRange = 240f..640f, steps = 39)
            Text("Sensibilidade atual: ${"%.1f".format(sensitivity)}"); Slider(sensitivity, { sensitivity = it }, valueRange = 0f..200f)
            Text("Sugestão inicial: ${"%.1f".format(suggestion)}", color = cyan, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { onDpi(targetDpi) }) { Text("Usar DPI $targetDpi") }; OutlinedButton(onClick = { baseDpi = targetDpi; sensitivity = suggestion }) { Text("Adotar escala") } }
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Sensibilidade: Geral | Red Dot | 2x | 4x | AWM | Botão de tiro") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            OutlinedButton(onClick = { onNoteSave(note) }, modifier = Modifier.fillMaxWidth()) { Text("Salvar anotações no perfil") }
        }
        Section("Mapa de HUD e ergonomia") {
            Text("Quantidade de dedos"); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(2,3,4).forEach { OutlinedButton(onClick = { fingers = it }) { Text(if (fingers == it) "✓ $it" else "$it dedos") } } }
            Text("Sugestão: distribua ações frequentes em zonas alcançáveis, mantenha áreas de toque afastadas do recorte da câmera e teste em partidas de treino.", color = Color.LightGray, fontSize = 12.sp)
            Text("Checklist: [ ] bordas curvas / recorte   [ ] botão de tiro   [ ] área de mira   [ ] alcance do polegar", color = Color.LightGray, fontSize = 12.sp)
            Text("Teste multi-touch: toque com vários dedos dentro da área abaixo. Máximo simultâneo observado: $pointers")
            Box(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFF202A3B), RoundedCornerShape(14.dp)).border(1.dp, purple, RoundedCornerShape(14.dp)).pointerInteropFilter { e ->
                when (e.actionMasked) { MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> pointers = maxOf(pointers, e.pointerCount); MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { } }
                true
            }, contentAlignment = androidx.compose.ui.Alignment.Center) { Text("ÁREA DE TESTE • ${fingers} dedos", color = Color.White) }
            Text("O teste mede apenas quantos contatos o Android reporta ao app; não mede latência física do painel.", color = Color.Gray, fontSize = 11.sp)
        }
        Section("Presets adicionais de resolução") {
            listOf(1600, 1800, 2000, 2400).forEach { height ->
                val width = (height * aspectRatio).toInt().coerceIn(480, 1440)
                val ratio = "%.3f".format(width.toFloat() / height)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text("${width} × ${height}", color = Color.White); Text("Proporção $ratio", color = Color.Gray, fontSize = 11.sp) }; TextButton(onClick = { onResolution(width, height) }) { Text("Aplicar") } }
            }
            Text("Atenção: reduzir resolução pode deixar textos e elementos menores ou menos nítidos. Confirme se a interface continua legível.", color = Color(0xFFFFB36B), fontSize = 11.sp)
        }
        Section("Presets adicionais de DPI e Hz") {
            listOf(Triple("Equilibrado", 400, 60), Triple("Economia extrema", 360, 60), Triple("Alta taxa / resposta", 420, 120), Triple("Estabilidade", 400, 60)).forEach { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text(p.first, color = Color.White); Text("${p.second} DPI • ${p.third} Hz", color = Color.LightGray, fontSize = 12.sp) }; TextButton(onClick = { onDpi(p.second); onHz(p.third) }) { Text("Aplicar valores") } }
            }
            Text("Resolução sugerida é proporcional ao formato detectado; a redução pode afetar legibilidade e não aumenta FPS garantidamente.", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun ThermalPage(temperature: Float?, samples: List<Float>, onCool: () -> Unit) {
    val peak = samples.maxOrNull()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Monitor térmico da sessão") {
            Text("Temperatura atual: ${temperature?.let { "%.1f °C".format(it) } ?: "indisponível"}", color = cyan, fontWeight = FontWeight.Bold)
            Text("Pico registrado: ${peak?.let { "%.1f °C".format(it) } ?: "sem amostras"}")
            if (samples.isNotEmpty()) Canvas(Modifier.fillMaxWidth().height(120.dp).background(Color(0xFF202A3B), RoundedCornerShape(12.dp))) {
                val min = (samples.minOrNull() ?: 20f).coerceAtMost(35f); val max = (samples.maxOrNull() ?: 40f).coerceAtLeast(min + 1f)
                val path = Path(); samples.forEachIndexed { i, v -> val x = if (samples.size == 1) 0f else size.width * i / (samples.size - 1); val y = size.height - ((v - min) / (max - min)).coerceIn(0f,1f) * size.height; if (i == 0) path.moveTo(x,y) else path.lineTo(x,y) }; drawPath(path, cyan, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
            } else Text("O histórico começa a ser preenchido enquanto o painel fica aberto.", color = Color.LightGray)
            Text("A temperatura da bateria é um indicador indireto; não representa todos os sensores internos nem prevê exatamente o thermal throttling.", color = Color.Gray, fontSize = 11.sp)
            val hot = temperature != null && temperature >= 40f
            if (hot) Text("Temperatura elevada: considere pausar, retirar a capa e reduzir brilho/carga.", color = Color(0xFFFFB36B))
            Button(onClick = onCool, modifier = Modifier.fillMaxWidth()) { Text("Modo Alívio: reduzir brilho do app") }
        }
    }
}

@Composable
fun SessionsPage(context: Context) {
    var game by remember { mutableStateOf("Free Fire") }
    var duration by remember { mutableStateOf("30") }
    var start by remember { mutableStateOf("") }
    var max by remember { mutableStateOf("") }
    var profile by remember { mutableStateOf("Equilibrado") }
    var note by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val sessions = remember(refresh) { LocalJournal.sessions(context).reversed() }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Registrar pós-partida") {
            OutlinedTextField(game, { game = it }, label = { Text("Jogo") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(4) }, label = { Text("Duração aproximada (minutos)") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(start, { start = it }, label = { Text("Temp. inicial °C") }, modifier = Modifier.weight(1f)); OutlinedTextField(max, { max = it }, label = { Text("Temp. máxima °C") }, modifier = Modifier.weight(1f)) }
            OutlinedTextField(profile, { profile = it }, label = { Text("Perfil usado") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(note, { note = it }, label = { Text("Notas: ping, sensação, estabilidade…") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { LocalJournal.addSession(context, GameSession(game.ifBlank { "Jogo" }, duration.toIntOrNull()?.coerceIn(0,1440) ?: 0, start.toFloatOrNull(), max.toFloatOrNull(), profile, note)); game = "Free Fire"; duration = "30"; start = ""; max = ""; note = ""; refresh++ }, modifier = Modifier.fillMaxWidth()) { Text("Salvar sessão") }
        }
        Section("Histórico local (${sessions.size})") {
            if (sessions.isEmpty()) Text("Nenhuma sessão registrada.", color = Color.LightGray)
            sessions.forEach { s ->
                Text("${s.game} • ${s.durationMinutes} min • ${s.profile}", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Temp.: ${s.startTempC?.let { "%.1f".format(it) } ?: "—"} → ${s.maxTempC?.let { "%.1f".format(it) } ?: "—"} °C", color = Color.LightGray, fontSize = 12.sp)
                Text(s.note.ifBlank { "Sem observações" }, color = Color.LightGray, fontSize = 12.sp)
                Text(SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(s.timestamp)), color = Color.Gray, fontSize = 10.sp)
                Divider(color = Color.DarkGray)
            }
        }
    }
}

@Composable
fun AutomationPage(context: Context, profile: GameProfile, onApply: () -> Unit, onRestore: () -> Unit) {
    var packageName by remember { mutableStateOf("com.dts.freefireth") }
    var enabled by remember { mutableStateOf(false) }
    var detected by remember { mutableStateOf("Aguardando detecção…") }
    var wasGame by remember { mutableStateOf(false) }
    val usage = ForegroundGameMonitor.hasUsageAccess(context)
    DisposableEffect(Unit) { onDispose { if (wasGame) onRestore() } }
    LaunchedEffect(enabled, packageName, usage) {
        while (enabled && usage) {
            val current = ForegroundGameMonitor.foregroundPackage(context)
            val isGame = current == packageName
            detected = current ?: "Não identificado"
            if (isGame && !wasGame) onApply()
            if (!isGame && wasGame) onRestore()
            wasGame = isGame
            delay(1800)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Automação por jogo — experimental") {
            Text("Usa Acesso a dados de uso do Android. A detecção depende do fabricante, pode atrasar e só roda enquanto o ApexPulse permanece ativo em segundo plano.", color = Color.LightGray, fontSize = 12.sp)
            Text("Permissão: ${if (usage) "concedida" else "necessária"}", color = if (usage) cyan else Color(0xFFFFB36B))
            if (!usage) Button(onClick = { ForegroundGameMonitor.requestUsageAccess(context) }) { Text("Abrir acesso de uso") }
            OutlinedTextField(packageName, { packageName = it.take(150) }, label = { Text("Pacote do jogo") }, modifier = Modifier.fillMaxWidth())
            Text("Perfil selecionado: ${profile.name} • ${profile.dpi} DPI • ${profile.refreshHz} Hz")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { val turningOff = enabled; enabled = !enabled; if (turningOff && wasGame) onRestore(); wasGame = false }) { Text(if (enabled) "Desativar automação" else "Ativar automação") }; OutlinedButton(onClick = onRestore) { Text("Restaurar agora") } }
            Text("Estado detectado: $detected", color = cyan)
            Text("Modo Foco não silencia notificações por conta própria: isso exigiria acesso especial de Não Perturbe. Brilho e orientação também podem ser limitados pelo Android.", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun ComfortPage(onCool: () -> Unit, onPanic: () -> Unit) {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }
    val maxVolume = remember { audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toFloat() / maxVolume) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Conforto visual e áudio") {
            Text("Ajuste de brilho e volume de mídia. O filtro global de luz azul/Night Light é controlado pelo Android ou fabricante.", color = Color.LightGray, fontSize = 12.sp)
            Button(onClick = onCool, modifier = Modifier.fillMaxWidth()) { Text("Brilho reduzido / Modo Alívio") }
            OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, modifier = Modifier.fillMaxWidth()) { Text("Abrir Luz Noturna / conforto ocular") }
            Text("Volume de mídia: ${(volume * 100).toInt()}%")
            Slider(value = volume, onValueChange = { volume = it }, valueRange = 0f..1f)
            OutlinedButton(onClick = { audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (volume * maxVolume).toInt(), 0) }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar volume") }
        }
        Section("Botão do Pânico / Stealth") {
            Text("Tenta restaurar resolução e DPI padrão e encerra o HUD flutuante. A restauração depende de Shizuku/Root autorizado.", color = Color.LightGray, fontSize = 12.sp)
            Button(onClick = onPanic, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9A3344))) { Text("RESTAURAR TUDO E FECHAR HUD") }
        }
    }
}

@Composable
fun LogsPage(logs: List<String>) {
    var filter by remember { mutableStateOf("Todos") }
    val visible = when(filter) { "Sucesso" -> logs.filter { it.contains("OK [") || it.contains("concluído", true) }; "Erro" -> logs.filter { it.contains("FALHOU [") || it.contains("erro", true) || it.contains("falha", true) }; else -> logs }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Histórico de comandos") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Todos","Sucesso","Erro").forEach { OutlinedButton(onClick = { filter = it }) { Text(if(filter == it) "✓ $it" else it) } } }
            if (visible.isEmpty()) Text("Nenhum registro para este filtro.", color = Color.LightGray)
            visible.forEach { Text(it, color = if (it.contains("FALHOU")) Color(0xFFFF9B9B) else Color.LightGray, fontSize = 11.sp) }
        }
    }
}
