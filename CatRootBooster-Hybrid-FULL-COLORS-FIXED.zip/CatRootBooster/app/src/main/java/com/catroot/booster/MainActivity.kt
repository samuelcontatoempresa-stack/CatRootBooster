package com.catroot.booster

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var shell: ShizukuShell
    private lateinit var screen: ScreenController
    private var savedBrightness: Int? = null
    private var savedDnd: Int? = null

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread { toast(if (result == PackageManager.PERMISSION_GRANTED) "Shizuku autorizado." else "Permissão do Shizuku negada.") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shell = ShizukuShell(this)
        screen = ScreenController(this)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(8, 7, 16))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = !url.startsWith("file:///android_asset/")
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "CatRoot")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3101)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface fun connectShizuku(): String {
            if (!Shizuku.pingBinder()) return "NOT_RUNNING"
            if (!shell.permitted()) { shell.request(); return "PERMISSION_REQUESTED" }
            return "CONNECTED"
        }

        @JavascriptInterface fun shizukuStatus(): String = when {
            !Shizuku.pingBinder() -> "NOT_RUNNING"
            !shell.permitted() -> "NO_PERMISSION"
            else -> "CONNECTED"
        }

        @JavascriptInterface fun getDeviceInfo(): String = try {
            val s = DeviceInfo.read(this@MainActivity)
            JSONObject().apply {
                put("width", s.width); put("height", s.height); put("dpi", s.dpi)
                put("rates", JSONArray(s.rates.map { it.toDouble() }))
                put("ramTotal", s.ramTotal); put("ramFree", s.ramFree)
                put("batteryTemp", s.batteryTemp.toDouble())
                put("platform", "Android ${Build.VERSION.RELEASE}")
                put("model", "${Build.MANUFACTURER} ${Build.MODEL}")
            }.toString()
        } catch (t: Throwable) { JSONObject().put("error", t.message ?: "Falha ao ler dispositivo").toString() }

        @JavascriptInterface fun applyRefreshRate(hz: Int): String = try {
            val snap = DeviceInfo.read(this@MainActivity)
            screen.setHz(hz, snap.rates)
            "OK"
        } catch (t: Throwable) { "ERRO: ${t.message ?: "não foi possível aplicar"}" }

        @JavascriptInterface fun applyScreenPreset(preset: String, width: Int, height: Int, dpi: Int): String = try {
            if (preset == "original") {
                screen.restore(); "RESTAURADO"
            } else {
                val s = DeviceInfo.read(this@MainActivity)
                val portrait = s.height >= s.width
                val target = when (preset) {
                    // Mantém a orientação atual: 4:3 em paisagem e 3:4 em retrato.
                    "43" -> if (portrait) Pair(s.width, (s.width * 4f / 3f).toInt())
                            else Pair(s.height * 4 / 3, s.height)
                    // Proporção de tablet 10:16, também respeitando retrato/paisagem.
                    "tablet" -> if (portrait) Pair(s.width, (s.width * 1.6f).toInt())
                                else Pair((s.height * 1.6f).toInt(), s.height)
                    "manual" -> Pair(width, height)
                    else -> throw IllegalArgumentException("Preset desconhecido")
                }
                val targetDpi = if (preset == "manual") dpi else s.dpi
                screen.setSize(target.first, target.second, targetDpi,
                    { seconds -> runOnUiThread { web.evaluateJavascript("window.nativeScreenCountdown && window.nativeScreenCountdown($seconds)", null) } },
                    { runOnUiThread { web.evaluateJavascript("window.nativeScreenRestored && window.nativeScreenRestored()", null) } })
                "APLICADO:${target.first}x${target.second}:$targetDpi"
            }
        } catch (t: Throwable) { "ERRO: ${t.message ?: "não foi possível alterar"}" }

        @JavascriptInterface fun confirmScreenPreset(): String = try { screen.confirm(); "OK" } catch (t: Throwable) { "ERRO: ${t.message}" }
        @JavascriptInterface fun restoreScreenPreset(): String = try { screen.restore(); "OK" } catch (t: Throwable) { "ERRO: ${t.message}" }

        @JavascriptInterface fun startHud(color: String, size: Int): String {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
                return "OVERLAY_PERMISSION_REQUIRED"
            }
            val intent = Intent(this@MainActivity, OverlayService::class.java)
                .putExtra("crosshair_color", color).putExtra("crosshair_size", size.coerceIn(12, 100))
            return try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                "STARTED"
            } catch (t: Throwable) { "ERRO: ${t.message}" }
        }

        @JavascriptInterface fun stopHud(): String = try {
            stopService(Intent(this@MainActivity, OverlayService::class.java)); "STOPPED"
        } catch (t: Throwable) { "ERRO: ${t.message}" }

        @JavascriptInterface fun openGameLauncher() {
            runOnUiThread { startActivity(Intent(this@MainActivity, GameLauncherActivity::class.java)) }
        }

        @JavascriptInterface fun applyOptimizer(brightnessPercent: Int, dnd: Boolean): String {
            return try {
                if (!Settings.System.canWrite(this@MainActivity)) {
                    runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
                    return "WRITE_SETTINGS_REQUIRED"
                }
                if (savedBrightness == null) savedBrightness = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
                val level = (brightnessPercent.coerceIn(1, 100) * 255 / 100)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, level)
                val nm = getSystemService(NotificationManager::class.java)
                if (dnd) {
                    if (!nm.isNotificationPolicyAccessGranted) {
                        runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                        return "DND_PERMISSION_REQUIRED"
                    }
                    if (savedDnd == null) savedDnd = nm.currentInterruptionFilter
                    nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                }
                "OK"
            } catch (t: Throwable) { "ERRO: ${t.message ?: "falha no otimizador"}" }
        }

        @JavascriptInterface fun restoreOptimizer(): String = try {
            savedBrightness?.let { if (Settings.System.canWrite(this@MainActivity)) Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, it) }
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) savedDnd?.let { nm.setInterruptionFilter(it) }
            savedBrightness = null; savedDnd = null
            "OK"
        } catch (t: Throwable) { "ERRO: ${t.message}" }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        web.removeJavascriptInterface("CatRoot")
        web.destroy()
        super.onDestroy()
    }
}
