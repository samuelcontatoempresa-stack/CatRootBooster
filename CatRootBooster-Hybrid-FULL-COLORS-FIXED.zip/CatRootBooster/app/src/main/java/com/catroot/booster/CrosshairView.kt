package com.catroot.booster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.View

/** HUD visual cosmético: não lê nem altera dados de outros aplicativos. */
class CrosshairView(c: Context) : View(c) {
    enum class Shape { DOT, CROSS, CIRCLE }
    var shape = Shape.CROSS
    var sizePx = 30f
    var opacity = 0.9f
    var color = Color.CYAN
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val x = width / 2f
        val y = height / 2f
        val alpha = (opacity.coerceIn(.1f, 1f) * 255).toInt()
        paint.color = color
        paint.alpha = alpha
        paint.strokeWidth = (sizePx / 13f).coerceIn(2f, 5f)
        paint.strokeCap = Paint.Cap.ROUND
        paint.style = Paint.Style.STROKE
        when (shape) {
            Shape.DOT -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(x, y, (sizePx / 7f).coerceAtLeast(3f), paint)
            }
            Shape.CROSS -> {
                val gap = (sizePx / 4.5f).coerceAtLeast(5f)
                canvas.drawLine(x - sizePx, y, x - gap, y, paint)
                canvas.drawLine(x + gap, y, x + sizePx, y, paint)
                canvas.drawLine(x, y - sizePx, x, y - gap, paint)
                canvas.drawLine(x, y + gap, x, y + sizePx, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(x, y, (sizePx / 16f).coerceAtLeast(2.5f), paint)
            }
            Shape.CIRCLE -> canvas.drawCircle(x, y, sizePx, paint)
        }
    }
}
