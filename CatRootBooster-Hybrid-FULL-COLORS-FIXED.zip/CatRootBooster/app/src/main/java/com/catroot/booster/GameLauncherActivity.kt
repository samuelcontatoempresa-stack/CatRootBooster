package com.catroot.booster

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class GameLauncherActivity : Activity() {
    private val cards = mutableListOf<Pair<String, android.content.pm.ApplicationInfo>>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private val purple = Color.rgb(168, 85, 247)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 8, 16), Color.rgb(31, 13, 49)))
        }
        val title = TextView(this).apply {
            text = "GAME LAUNCHER"
            textSize = 23f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title)
        val subtitle = TextView(this).apply {
            text = "Seus jogos em um só lugar • toque para abrir"
            textSize = 12f; setTextColor(0xFFBBA7CC.toInt()); setPadding(0, 5, 0, 18)
        }
        page.addView(subtitle)
        search = EditText(this).apply {
            hint = "Pesquisar jogos..."; setSingleLine(true); textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(0xFF9D8BAA.toInt())
            setPadding(18, 8, 18, 8)
            background = rounded(0xFF21152F.toInt(), 18)
        }
        page.addView(search, LinearLayout.LayoutParams(-1, 52))
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 14, 0, 12) }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val back = TextView(this).apply {
            text = "← VOLTAR AO CAT ROOT"; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF7136B5.toInt(), 18); setPadding(12, 15, 12, 15)
            setOnClickListener { finish() }
        }
        page.addView(back, LinearLayout.LayoutParams(-1, 52))
        setContentView(page)

        val pm = packageManager
        val installed = pm.getInstalledApplications(0).filter { app ->
            val launchable = pm.getLaunchIntentForPackage(app.packageName) != null
            val gameCategory = android.os.Build.VERSION.SDK_INT >= 26 && app.category == ApplicationInfo.CATEGORY_GAME
            launchable && gameCategory
        }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        cards.clear()
        installed.forEach { cards.add(pm.getApplicationLabel(it).toString() to it) }
        render("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun render(query: String) {
        list.removeAllViews()
        val results = cards.filter { it.first.contains(query, ignoreCase = true) }
        if (results.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (cards.isEmpty()) "Nenhum jogo detectado. Instale um jogo e atualize a lista." else "Nenhum resultado para essa pesquisa."
                setTextColor(0xFFBBA7CC.toInt()); textSize = 14f; setPadding(8, 28, 8, 28)
            })
            return
        }
        results.forEach { (name, app) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(0xFF171020.toInt(), 18); setPadding(14, 12, 14, 12)
                val lp = LinearLayout.LayoutParams(-1, 76); lp.bottomMargin = 10; layoutParams = lp
                setOnClickListener { packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } }
            }
            val icon = ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(app)) }
            row.addView(icon, LinearLayout.LayoutParams(48, 48))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(13, 0, 0, 0) }
            labels.addView(TextView(this).apply { text = name; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
            labels.addView(TextView(this).apply { text = "TOQUE PARA INICIAR"; textSize = 10f; setTextColor(purple); setPadding(0, 4, 0, 0) })
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = "›"; textSize = 27f; setTextColor(purple) })
            list.addView(row)
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius * resources.displayMetrics.density
        setStroke((1 * resources.displayMetrics.density).toInt().coerceAtLeast(1), 0xFF49305D.toInt())
    }
}
