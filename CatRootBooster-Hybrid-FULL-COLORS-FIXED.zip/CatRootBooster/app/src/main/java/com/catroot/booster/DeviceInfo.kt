package com.catroot.booster
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.view.WindowManager

data class DeviceSnapshot(val width:Int,val height:Int,val dpi:Int,val rates:List<Float>,val ramTotal:Long,val ramFree:Long,val batteryTemp:Float)
object DeviceInfo {
    fun read(c:Context):DeviceSnapshot {
        val dm=c.resources.displayMetrics
        val display=c.getSystemService(WindowManager::class.java).defaultDisplay
        val rates=display.supportedModes.map { it.refreshRate }.distinct().sorted()
        val mem=ActivityManager.MemoryInfo(); c.getSystemService(ActivityManager::class.java).getMemoryInfo(mem)
        val battery=c.registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp=(battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0) ?: 0)/10f
        return DeviceSnapshot(dm.widthPixels,dm.heightPixels,dm.densityDpi,rates,mem.totalMem/1048576,mem.availMem/1048576,temp)
    }
}
