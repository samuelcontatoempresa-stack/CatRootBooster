package com.catroot.booster

import android.os.Binder
import android.os.Parcel
import java.io.BufferedReader
import java.io.InputStreamReader

/** Binder executado no processo UserService do Shizuku. */
class ShizukuCommandService : Binder() {
    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        if (code == DESTROY_TRANSACTION) {
            Thread { runCatching { System.exit(0) } }.start()
            return true
        }
        if (code != COMMAND_TRANSACTION || reply == null) return super.onTransact(code, data, reply, flags)
        data.enforceInterface(DESCRIPTOR)
        val command = data.readString().orEmpty()
        return try {
            require(isAllowed(command)) { "Comando não permitido." }
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val exitCode = process.waitFor()
            check(exitCode == 0) { output.ifBlank { "Falha ao executar comando." } }
            reply.writeNoException()
            reply.writeString(output.ifBlank { "OK" })
            true
        } catch (error: Throwable) {
            reply.writeException(error as? Exception ?: RuntimeException(error))
            true
        }
    }

    private fun isAllowed(command: String): Boolean =
        command == "wm size reset" || command == "wm density reset" ||
        command == "wm size" || command == "wm density" ||
        Regex("wm size [1-9][0-9]{2,4}x[1-9][0-9]{2,4}").matches(command) ||
        Regex("wm density [1-9][0-9]{1,3}").matches(command) ||
        Regex("settings put system (peak_refresh_rate|min_refresh_rate) (60|90|120|144)(\\.0)?").matches(command)

    companion object {
        const val DESCRIPTOR = "com.catroot.booster.commands"
        private const val COMMAND_TRANSACTION = 1
        private const val DESTROY_TRANSACTION = 16777115
    }
}
