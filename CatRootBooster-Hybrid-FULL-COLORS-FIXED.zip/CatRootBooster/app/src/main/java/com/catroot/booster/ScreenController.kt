package com.catroot.booster

import android.content.Context
import android.os.CountDownTimer

/** Aplica alterações temporárias de resolução/DPI com restauração automática. */
class ScreenController(context: Context) {
    private val shell = ShizukuShell(context)
    private var timer: CountDownTimer? = null
    private var oldSize: String? = null
    private var oldDensity: String? = null
    private var originalCaptured = false

    @Synchronized
    fun setSize(w: Int, h: Int, dpi: Int, tickCallback: (Int) -> Unit, restoreCallback: () -> Unit) {
        require(w in 320..8000 && h in 320..8000 && dpi in 80..1000) {
            "Resolução ou DPI fora do limite permitido."
        }
        check(shell.permitted()) { "Conecte e autorize o Shizuku primeiro." }

        if (!originalCaptured) {
            val sizeOutput = shell.run("wm size")
            val densityOutput = shell.run("wm density")
            oldSize = parseOverride(sizeOutput, "size")
            oldDensity = parseOverride(densityOutput, "density")
            originalCaptured = true
        }

        try {
            shell.run("wm size ${w}x${h}")
            shell.run("wm density $dpi")
        } catch (error: Throwable) {
            // Não deixa uma resolução parcial aplicada se o comando de DPI falhar.
            runCatching { restoreValues() }
            throw error
        }

        timer?.cancel()
        timer = object : CountDownTimer(10_000, 1_000) {
            override fun onTick(ms: Long) = tickCallback(((ms + 999) / 1000).toInt())
            override fun onFinish() {
                runCatching { restore() }
                restoreCallback()
            }
        }.start()
    }

    private fun parseOverride(output: String, kind: String): String? {
        val label = if (kind == "size") "Override size:" else "Override density:"
        return output.lineSequence().firstOrNull { it.trim().startsWith(label, ignoreCase = true) }
            ?.substringAfter(':')?.trim()?.takeIf { it.isNotBlank() }
    }

    @Synchronized
    fun confirm() {
        timer?.cancel()
        timer = null
    }

    @Synchronized
    fun restore() {
        timer?.cancel()
        timer = null
        if (!originalCaptured) return
        restoreValues()
        oldSize = null
        oldDensity = null
        originalCaptured = false
    }

    private fun restoreValues() {
        val size = oldSize
        val density = oldDensity
        if (size != null && Regex("[1-9][0-9]{2,4}x[1-9][0-9]{2,4}").matches(size)) {
            shell.run("wm size $size")
        } else {
            shell.run("wm size reset")
        }
        if (density != null && Regex("[1-9][0-9]{1,3}").matches(density)) {
            shell.run("wm density $density")
        } else {
            shell.run("wm density reset")
        }
    }

    fun setHz(hz: Int, rates: List<Float>) {
        require(hz in 30..240) { "Frequência inválida." }
        require(rates.any { kotlin.math.abs(it - hz) < 1.5f }) { "$hz Hz não é suportado pelo painel." }
        shell.run("settings put system peak_refresh_rate ${hz}.0")
        shell.run("settings put system min_refresh_rate ${hz}.0")
    }
}
