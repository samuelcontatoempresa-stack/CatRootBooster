# CAT ROOT BOOSTER — Android Hybrid

Projeto Android híbrido: interface HTML/CSS/JavaScript exibida em WebView local e funções nativas em Kotlin.

## Abrir e compilar
1. Extraia a pasta `CatRootBooster`.
2. Abra essa pasta no Android Studio.
3. Use JDK 17 e Android SDK 35.
4. Aguarde a sincronização do Gradle e execute em um aparelho Android 8.0 ou superior.

O projeto não inclui `gradlew`; use o Gradle integrado ao Android Studio.

## Recursos conectados ao Android
- Interface original em `app/src/main/assets/index.html`.
- Ponte JavaScript/Kotlin `CatRoot` dentro de `MainActivity.kt`.
- Shizuku para comandos restritos de resolução, densidade e preferências de refresh rate.
- Leitura nativa de resolução, DPI, modos de tela, RAM e temperatura da bateria.
- Presets de resolução/DPI com restauração automática após 10 segundos, caso não sejam confirmados.
- HUD sobre outros aplicativos por serviço em primeiro plano e permissão de sobreposição; inclui mira configurável.
- Launcher nativo para aplicativos que declaram a categoria GAME.
- Ajuste de brilho e Não Perturbe mediante permissões do Android.

## Configuração inicial no aparelho
1. Instale e inicie o Shizuku conforme as instruções oficiais do próprio Shizuku.
2. Abra o CatRoot Booster e toque em **Conectar / solicitar Shizuku**.
3. Autorize o aplicativo na solicitação do Shizuku.
4. Para resolução/DPI e refresh rate, mantenha o Shizuku ativo e autorizado.
5. Para HUD, conceda **Sobrepor a outros apps** e toque novamente em ativar.
6. Para brilho/DND, conceda as permissões solicitadas nas configurações do Android.

## Limites importantes
- A taxa solicitada precisa existir entre os modos suportados pelo painel; o app não cria suporte a 90/120/144 Hz.
- Alterações de resolução/DPI podem ser bloqueadas por alguns fabricantes. O app tenta guardar o override anterior e restaurá-lo automaticamente em 10 segundos, mas mantenha o botão de restauração acessível.
- A restauração automática depende de o Android manter o processo do app ativo durante a contagem.
- O launcher lista apps que declaram `CATEGORY_GAME`; jogos que não declaram essa categoria podem não aparecer.
- O HUD é um painel informativo e uma mira visual estática. Não lê nem modifica jogos, não mede FPS interno de jogos de terceiros e não oferece assistência de mira em jogos.
- O controle de brilho e Não Perturbe depende das permissões especiais correspondentes.
- O estado de brilho/DND salvo em memória é restaurável durante a mesma execução do app; se o processo for encerrado, a restauração manual pode não ter os valores anteriores em memória.
- Nenhuma função promete aumentar FPS por si só; os controles apenas aplicam configurações do sistema quando o Android permite.

## Estrutura
- `app/src/main/assets/index.html` — interface visual.
- `MainActivity.kt` — WebView e ponte JavaScript/Kotlin.
- `ShizukuShell.kt` e `ShizukuCommandService.kt` — UserService e comandos permitidos via Shizuku.
- `ScreenController.kt` — resolução, DPI, temporizador e refresh rate.
- `OverlayService.kt` e `CrosshairView.kt` — HUD flutuante.
- `DeviceInfo.kt` — informações do dispositivo.
- `GameLauncherActivity.kt` — lista e abertura de jogos detectados.


## Atualização da interface e build
- Painel escuro atualizado, monitoramento nativo (quando fornecido pelo Android), perfis locais e central de jogos com pesquisa.
- Taxas de atualização são listadas a partir dos modos reais do display; apenas valores suportados podem ser aplicados.
- Tela esticada com cálculo retrato/paisagem e restauração temporizada. Alterações de resolução/DPI podem afetar a interface do sistema; confirme somente se a tela continuar utilizável.
- Ícone adaptativo CatRoot incluído em `app/src/main/res`.
- Workflow de exemplo em `.github/workflows/android.yml`. Ele espera que `CatRootBooster-Hybrid.zip` esteja na raiz do repositório.

Perfis e launcher são ferramentas de organização e abertura de jogos; não prometem FPS adicional nem modificam memória/processos de jogos.
