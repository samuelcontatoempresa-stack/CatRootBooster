# ApexPulse Tuner — expansão 1.2.0

Projeto Android nativo em Kotlin + Jetpack Compose. Mantém a base anterior de Shizuku/Root, comandos permitidos, tela esticada com confirmação, HUD flutuante e JSON de perfis; acrescenta ferramentas locais para laboratório, telemetria e organização de sessões.

## Novos módulos

- **Perfis ampliados:** Equilibrado, Economia Extrema, Alta Taxa/Resposta e Teste de Estabilidade; favoritos, duplicação, edição de nome/pacote/DPI/Hz, ordenação e persistência local.
- **Laboratório de sensibilidade:** conversor proporcional de DPI com aviso de que cada jogo usa sua própria curva; campo de anotações; presets de DPI/Hz e resoluções com proporção e aviso de legibilidade.
- **HUD e ergonomia:** checklist orientativo de 2/3/4 dedos e área multi-touch que informa o maior número de contatos simultâneos reportado pelo Android.
- **Monitor térmico:** amostras da temperatura da bateria guardadas localmente, gráfico simples e pico observado; botão Modo Alívio reduz o brilho quando a permissão de escrita do sistema foi concedida.
- **Diário pós-partida:** registro manual de jogo, duração aproximada, temperaturas, perfil e notas, armazenado no aparelho.
- **Automação experimental:** detecta mudança de app em primeiro plano via Usage Access e aplica/restaura DPI/Hz do perfil. O usuário precisa conceder Acesso a dados de uso e manter o ApexPulse ativo; fabricantes podem limitar/atrasar eventos.
- **Conforto visual e áudio:** atalho para configurações de Luz Noturna, controle de volume de mídia e brilho; o filtro global de luz azul continua sob controle do Android/fabricante.
- **Stealth / pânico:** solicita reset de resolução/DPI e fecha o HUD.
- **Logs:** histórico com horário e filtro de sucesso/erro.
- **Backup:** JSON de perfis e snapshot de resolução, DPI, Hz e perfis.
- **Restauração de emergência:** snapshot pendente em SharedPreferences; na próxima abertura o app tenta reaplicar resolução/DPI/Hz originais se o acesso Shizuku/Root estiver disponível.
- **HUD flutuante ampliado:** telemetria compacta (temperatura, RAM livre e Hz), alternância de tela, reset de resolução/DPI e brilho quando autorizado.

## Limites e permissões importantes

- **Shizuku/Root:** necessários para os comandos `wm size`, `wm density` e ajustes de taxa do sistema. Sem autorização, o app informa que nada foi aplicado.
- **Automação:** requer Acesso a dados de uso nas Configurações. A detecção é experimental, não é serviço infalível e pode ser suspensa pelo sistema/fabricante.
- **Notificações/Modo Não Perturbe:** não são silenciadas automaticamente. O controle global exige acesso especial concedido pelo usuário.
- **Brilho:** alteração global requer a permissão especial “Modificar configurações do sistema”.
- **Orientação:** o Android não oferece uma forma pública confiável para forçar a orientação de outro app a partir deste serviço.
- **FPS de outro jogo:** não é exposto de forma geral por APIs públicas comuns. O app mostra Hz da tela, RAM e temperatura da bateria; não inventa FPS.
- **Temperatura:** é a temperatura da bateria, não todos os sensores térmicos internos.
- **Sensibilidade:** o conversor é uma estimativa matemática inicial, não altera diretamente a sensibilidade dentro do jogo.
- **Multi-touch:** conta contatos reportados ao app, não mede latência física do painel.
- **Restauração:** o estado pendente sobrevive ao encerramento do processo, mas a restauração na abertura depende de Shizuku/Root autorizado. O rollback de 10 segundos também depende do processo continuar ativo durante a contagem.

## Build no GitHub Actions

O repositório não inclui `gradlew` nem `gradle-wrapper.jar`. O workflow instala Gradle 8.9 no runner e executa `gradle :app:assembleDebug`; portanto, a compilação no GitHub Actions não depende do wrapper. Para compilar localmente, use Gradle 8.9 instalado e Android SDK Platform 35 / Build Tools 35.0.0.

O workflow gera o APK em `app/build/outputs/apk/debug/` e publica como artifact `ApexPulseTuner-debug-apk`.

## Verificação desta entrega

Foi possível verificar estrutura, manifest, workflow YAML e integridade do ZIP. Este ambiente não possui Gradle/Android SDK configurados para executar `assembleDebug`; portanto, **não afirmo que a compilação Android foi concluída nem que o APK está livre de erros**. Rode GitHub Actions e, se houver erro, envie o log completo para correção.
