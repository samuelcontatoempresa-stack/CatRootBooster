package com.apexpulse.tuner.system

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/** Executes only app-generated, validated commands. No arbitrary shell input is accepted. */
object TunerExecutor {
    const val SHIZUKU_REQUEST_CODE = 7104
    enum class Mode { SHIZUKU, ROOT, SAFE }
    data class Result(val success: Boolean, val command: String, val output: String, val mode: Mode) {
        val summary: String get() = if (success) "OK [$mode]: $output" else "FALHOU [$mode]: $output"
    }
    @Volatile private var rootEnabled = false
    @Volatile private var permissionCallback: ((Boolean) -> Unit)? = null
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) permissionCallback?.invoke(grantResult == PackageManager.PERMISSION_GRANTED)
    }
    @Volatile private var listenerRegistered = false

    fun setRootFallbackEnabled(enabled: Boolean) { rootEnabled = enabled }
    fun shizukuAvailable(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
    fun shizukuGranted(): Boolean = shizukuAvailable() && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
    fun status(): String = when { shizukuGranted() -> "Shizuku autorizado"; shizukuAvailable() -> "Shizuku conectado — autorização pendente"; rootEnabled -> "Fallback Root habilitado"; else -> "Modo seguro (sem acesso elevado)" }

    fun requestShizuku(onResult: (Boolean) -> Unit) {
        permissionCallback = onResult
        if (!shizukuAvailable()) { onResult(false); return }
        if (shizukuGranted()) { onResult(true); return }
        runCatching {
            if (!listenerRegistered) { Shizuku.addRequestPermissionResultListener(permissionListener); listenerRegistered = true }
            Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
        }.onFailure { onResult(false) }
    }

    fun run(context: Context, command: String, simulateWhenUnavailable: Boolean = true): Result {
        val allowed = validate(command)
        if (!allowed) return Result(false, command, "Comando bloqueado pela lista de segurança.", Mode.SAFE)
        if (shizukuGranted()) return runCatching {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", "$command 2>&1"), null, null)
            collect(process, command, Mode.SHIZUKU)
        }.getOrElse { Result(false, command, it.message ?: "Falha ao iniciar Shizuku", Mode.SHIZUKU) }
        if (rootEnabled) return runCatching {
            val process = ProcessBuilder("su", "-c", "$command 2>&1").redirectErrorStream(true).start()
            collect(process, command, Mode.ROOT)
        }.getOrElse { Result(false, command, it.message ?: "Root indisponível", Mode.ROOT) }
        return Result(false, command, if (simulateWhenUnavailable) "Simulação: conecte e autorize Shizuku ou habilite Root nas opções. Nenhuma alteração foi aplicada." else "Sem permissão elevada; nenhuma alteração aplicada.", Mode.SAFE)
    }

    private fun collect(process: Process, command: String, mode: Mode): Result {
        val text = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }.trim()
        val exit = process.waitFor()
        return Result(exit == 0, command, (text.ifBlank { if (exit == 0) "Comando concluído sem saída." else "Processo terminou com código $exit." }), mode)
    }

    private fun validate(c: String): Boolean {
        if (c.length > 180 || c.contains(';') || c.contains('`') || c.contains('$') || c.contains('|') || c.contains('&') || c.contains('>') || c.contains('<')) return false
        return c.matches(Regex("wm density (reset|[1-9][0-9]{2,3})")) ||
            c.matches(Regex("wm size (reset|[1-9][0-9]{2,3}x[1-9][0-9]{2,3})")) ||
            c.matches(Regex("settings put system (peak_refresh_rate|min_refresh_rate|user_refresh_rate) (30|60|90|120|144)(\\.0)?")) ||
            (Build.VERSION.SDK_INT >= 31 && c.matches(Regex("cmd game mode (standard|performance|battery) [A-Za-z0-9_.]+")))
    }

    fun setDpi(context: Context, dpi: Int) = run(context, "wm density ${dpi.coerceIn(240, 640)}")
    fun resetDpi(context: Context) = run(context, "wm density reset")
    fun setResolution(context: Context, width: Int, height: Int) = run(context, "wm size ${width.coerceIn(480, 1440)}x${height.coerceIn(800, 3200)}")
    fun resetResolution(context: Context) = run(context, "wm size reset")
    fun setRefresh(context: Context, hz: Int): List<Result> {
        val safe = listOf(30, 60, 90, 120, 144).minBy { kotlin.math.abs(it - hz) }
        return listOf("peak_refresh_rate", "min_refresh_rate", "user_refresh_rate").map { run(context, "settings put system $it $safe.0") }
    }
    fun gameMode(context: Context, packageName: String, mode: String = "performance"): Result {
        if (!packageName.matches(Regex("[A-Za-z0-9_.]+"))) return Result(false, "cmd game mode", "Pacote inválido.", Mode.SAFE)
        return run(context, "cmd game mode ${if (mode in listOf("standard", "performance", "battery")) mode else "standard"} $packageName")
    }
}
