package com.apexpulse.tuner.system

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.WindowManager.LayoutParams
import android.os.Handler
import android.os.Looper

class FloatingHudService : Service() {
    private lateinit var wm: WindowManager
    private var view: LinearLayout? = null
    private var info: TextView? = null
    private var stretched = false
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            val t = TelemetryRepository.read(this@FloatingHudService)
            info?.text = "${t.batteryC?.let { "%.1f°C".format(it) } ?: "Temp. —"} • RAM livre ${t.ramAvailableMb} MB • ${t.refreshHz.toInt()} Hz • FPS indisponível"
            handler.postDelayed(this, 2500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(0xE6101827.toInt()) }
        val label = TextView(this).apply { text = "APEXPULSE • HUD  ⠿"; setTextColor(Color.WHITE); textSize = 12f; setPadding(4,4,4,8) }
        info = TextView(this).apply { setTextColor(0xFF00D9F5.toInt()); textSize = 10f }
        val stretchButton = Button(this).apply { text = "Tela esticada ON/OFF"; setOnClickListener { val r = if (!stretched) TunerExecutor.setResolution(this@FloatingHudService,1080,1920) else TunerExecutor.resetResolution(this@FloatingHudService); if (r.success) stretched = !stretched; info?.text = r.summary } }
        val reset = Button(this).apply { text = "Reset resolução + DPI"; setOnClickListener { val a=TunerExecutor.resetResolution(this@FloatingHudService); val b=TunerExecutor.resetDpi(this@FloatingHudService); stretched=false; info?.text = "${a.summary} • ${b.summary}" } }
        val brightness = Button(this).apply { text = "Brilho 40%"; setOnClickListener { if (Settings.System.canWrite(this@FloatingHudService)) { val ok=Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 102); info?.text = if(ok) "Brilho reduzido." else "Falha ao alterar brilho." } else { val i=Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); info?.text = "Conceda permissão de brilho nas Configurações." } } }
        val close = Button(this).apply { text = "Fechar HUD"; setOnClickListener { stopSelf() } }
        box.addView(label); box.addView(info); box.addView(stretchButton); box.addView(reset); box.addView(brightness); box.addView(close)
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE
        val params = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, type, LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 160 }
        // Arrastar somente pela faixa de título, preservando o clique dos botões.
        label.setOnTouchListener(object : android.view.View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; override fun onTouch(v: android.view.View, e: MotionEvent): Boolean { when(e.action) { MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return true }; MotionEvent.ACTION_MOVE -> { params.x=ox+(e.rawX-sx).toInt(); params.y=oy+(e.rawY-sy).toInt(); runCatching { wm.updateViewLayout(box,params) }; return true }; MotionEvent.ACTION_UP -> return true }; return false } })
        view = box
        runCatching { wm.addView(box, params); handler.post(refreshTask) }.onFailure { stopSelf() }
    }
    override fun onDestroy() { handler.removeCallbacks(refreshTask); view?.let { runCatching { wm.removeView(it) } }; view=null; super.onDestroy() }
}
