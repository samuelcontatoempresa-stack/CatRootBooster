package com.apexpulse.tuner.data

import org.json.JSONArray
import org.json.JSONObject

object ProfileJson {
    fun export(profiles: List<GameProfile>): String = JSONArray().apply { profiles.forEach { p -> put(JSONObject().apply { put("name",p.name); put("category",p.category); put("dpi",p.dpi); put("refreshHz",p.refreshHz); put("note",p.note); put("packageName",p.packageName); put("favorite",p.favorite); put("lastUsed",p.lastUsed) }) } }.toString(2)
    fun import(json: String): List<GameProfile> {
        val array = JSONArray(json)
        require(array.length() in 1..100) { "O JSON deve conter entre 1 e 100 perfis." }
        return (0 until array.length()).map { i -> val o = array.getJSONObject(i); GameProfile(o.optString("name").take(60).ifBlank { "Perfil importado ${i+1}" }, o.optString("category", "Personalizado").take(40), o.optInt("dpi", 420).coerceIn(240,640), o.optInt("refreshHz",60).coerceIn(30,144), o.optString("note").take(300), o.optString("packageName").take(150), o.optBoolean("favorite", false), o.optLong("lastUsed", 0L)) }
    }
}
