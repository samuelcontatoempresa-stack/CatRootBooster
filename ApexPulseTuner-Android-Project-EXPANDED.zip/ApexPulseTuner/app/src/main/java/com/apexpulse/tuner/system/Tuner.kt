package com.apexpulse.tuner.system

import android.content.Context
import android.provider.Settings

 data class ActionResult(val ok: Boolean, val message: String)
object Tuner {
    fun accessMode(): String = TunerExecutor.status()
    fun requestShizukuPermission(requestCode: Int) { TunerExecutor.requestShizuku {} }
    fun setBrightness(context: Context, value: Int): ActionResult = try {
        if (!Settings.System.canWrite(context)) ActionResult(false, "Permita modificar configurações do sistema nas Configurações do Android.")
        else { Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value.coerceIn(10,100)*255/100); ActionResult(true, "Brilho ajustado.") }
    } catch (e: Exception) { ActionResult(false, e.message ?: "Falha no brilho.") }
    fun screenPresetInfo(): ActionResult = ActionResult(false, "Use o controlador A16 com Shizuku autorizado para aplicar; a confirmação de 10 segundos restaura automaticamente.")
    fun highRefreshInfo(requested: Int): ActionResult = ActionResult(false, "Taxa solicitada: $requested Hz. O hardware e o Android determinam os modos realmente disponíveis.")
}
