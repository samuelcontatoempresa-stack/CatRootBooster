package com.apexpulse.tuner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.apexpulse.tuner.data.*
import com.apexpulse.tuner.system.*

private val bg = Color(0xFF080B14); private val panel = Color(0xFF121A2B); private val purple = Color(0xFF9B72FF); private val cyan = Color(0xFF00D9F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ApexApp() } }
}

@Composable fun ApexApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var page by remember { mutableStateOf("Painel") }
    var info by remember { mutableStateOf("Pronto para diagnóstico") }
    var dpi by remember { mutableFloatStateOf(420f) }
    var hz by remember { mutableIntStateOf(60) }
    var profiles by remember { mutableStateOf(runCatching { ProfileJson.import(context.getSharedPreferences("apexpulse_profiles", android.content.Context.MODE_PRIVATE).getString("profiles_json", "") ?: "") }.getOrDefault(defaultProfiles)) }
    var selected by remember { mutableStateOf(profiles.first()) }
    var snapshot by remember { mutableStateOf(DeviceInspector.read(context)) }
    var telemetry by remember { mutableStateOf(TelemetryRepository.read(context)) }
    var commandLog by remember { mutableStateOf(listOf<String>()) }
    var countdown by remember { mutableIntStateOf(0) }
    var jsonText by remember { mutableStateOf("") }
    var rootMode by remember { mutableStateOf(false) }
    var profileNameEdit by remember { mutableStateOf("") }
    var selectedNameEdit by remember { mutableStateOf(profiles.first().name) }
    var profilePackageEdit by remember { mutableStateOf("") }
    var profileDpiEdit by remember { mutableStateOf("420") }
    var profileHzEdit by remember { mutableStateOf("60") }
    var sortFavorites by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val stretch = remember { A16StretchController(context, scope, { countdown = it }, { msg -> val line = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())} • $msg"; info = msg; commandLog = (listOf(line) + commandLog).take(100) }) }
    LaunchedEffect(Unit) {
        val pending = LocalJournal.pendingRestore(context)
        if (pending != null) {
            val dims = Regex("(\\d+)\\s*[×x]\\s*(\\d+)").find(pending.resolution)
            val results = mutableListOf<TunerExecutor.Result>()
            if (dims != null) results.add(TunerExecutor.setResolution(context, dims.groupValues[1].toInt(), dims.groupValues[2].toInt())) else results.add(TunerExecutor.resetResolution(context))
            if (pending.density in 240..640) results.add(TunerExecutor.setDpi(context, pending.density))
            results.addAll(TunerExecutor.setRefresh(context, pending.refreshHz.toInt().coerceIn(30,144)))
            if (results.all { it.success }) { LocalJournal.savePendingRestore(context, null); info = "Restauração de emergência aplicada na abertura." }
            else info = "Há restauração pendente; autorize Shizuku/Root e use Restaurar no modo Conforto."
        }
        while (true) { telemetry = TelemetryRepository.read(context); LocalJournal.addTemperature(context, telemetry.batteryC); delay(2500) }
    }
    LaunchedEffect(profiles) { context.getSharedPreferences("apexpulse_profiles", android.content.Context.MODE_PRIVATE).edit().putString("profiles_json", ProfileJson.export(profiles)).apply() }
    fun logResult(r: TunerExecutor.Result) { val line = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())} • ${r.summary}"; info = r.summary; commandLog = (listOf(line) + commandLog).take(100) }

    MaterialTheme(colorScheme = darkColorScheme(primary = purple, secondary = cyan, background = bg, surface = panel)) {
        Scaffold(containerColor = bg, bottomBar = { NavigationBar(containerColor = panel) { listOf("Painel", "Ajustes", "Perfis", "Aparelho", "Mais").forEach { item -> NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Icon(when(item){"Painel"->Icons.Default.Dashboard;"Ajustes"->Icons.Default.Tune;"Perfis"->Icons.Default.SportsEsports;else->Icons.Default.PhoneAndroid}, contentDescription = item) }, label = { Text(item) }) } } }) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text("APEXPULSE", color = Color.White, fontSize = 25.sp); Text("TUNER  •  PERFORMANCE SUITE", color = cyan, fontSize = 10.sp) }; AssistChip(onClick = { info = Tuner.accessMode() }, label = { Text("● ${Tuner.accessMode()}") }) } }
                item { Section("Acesso e permissões") {
                    Text(TunerExecutor.status(), color = cyan)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { TunerExecutor.requestShizuku { granted -> scope.launch { info = if (granted) "Shizuku autorizado." else "Shizuku não autorizado ou indisponível." } } }) { Text("Solicitar Shizuku") }
                        OutlinedButton(onClick = { rootMode = !rootMode; TunerExecutor.setRootFallbackEnabled(rootMode); info = if (rootMode) "Fallback su habilitado. O Android ainda solicitará autorização Root." else "Fallback Root desabilitado." }) { Text(if(rootMode) "Root: ON" else "Root: OFF") }
                    }
                } }
                item { when(page) {
                    "Painel" -> { Section("Visão geral") { Text("Seu dispositivo, em um só lugar.", color = Color.LightGray); Text("Modelo: ${snapshot.model}"); Text("RAM: ${snapshot.ram}"); Text("Bateria: ${snapshot.batteryC}"); Text("Tela: ${snapshot.resolution} • ${snapshot.refreshRates} Hz"); Text("RAM usada: ${telemetry.ramUsedMb} MB / ${telemetry.ramTotalMb} MB"); Text("Armazenamento livre: ${"%.2f".format(telemetry.storageFreeGb)} GB"); Text("Temperatura: ${telemetry.batteryC?.let { "%.1f °C".format(it) } ?: "Indisponível"}") }; Section("Ação rápida") { Button(onClick = { page = "Ajustes"; info = "Ajustes prontos para configurar." }, modifier = Modifier.fillMaxWidth()) { Text("Modo Competitivo A16 5G") }; OutlinedButton(onClick = { page = "Ajustes" }, modifier = Modifier.fillMaxWidth()) { Text("Abrir Tela Esticada") } } }
                    "Ajustes" -> { Section("DPI e tela") { Text("DPI: ${dpi.toInt()}"); Slider(value = dpi, onValueChange = { dpi = it }, valueRange = 320f..520f); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(360f, 400f, 420f, 460f).forEach { OutlinedButton(onClick = { dpi = it }) { Text(it.toInt().toString()) } } }; Text("Tela Esticada — Galaxy A16 5G", color = cyan); Text("Prévia e diagnóstico. A aplicação de resolução/DPI permanece protegida até haver acesso elevado e confirmação.", color = Color.LightGray); Button(onClick = { stretch.apply(1080,1920,dpi.toInt()) }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar Tela Esticada A16 (10s para confirmar)") }
                        if (countdown > 0) { Text("Confirme em $countdown segundos", color = cyan); Button(onClick = { stretch.keep() }, modifier = Modifier.fillMaxWidth()) { Text("Manter ajuste") } }
                        OutlinedButton(onClick = { stretch.restore(); dpi = snapshot.density.toFloat() }, modifier = Modifier.fillMaxWidth()) { Text("Voltar Tela Normal / Reset DPI") }
                        Button(onClick = { logResult(TunerExecutor.setDpi(context,dpi.toInt())) }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar DPI ${dpi.toInt()}") }
                        Button(onClick = { val results=TunerExecutor.setRefresh(context,hz); results.forEach { logResult(it) } }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar Hz solicitado") } }; Section("Taxa de atualização") { Text("Hz solicitado: $hz"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(60,90,120,144).forEach { OutlinedButton(onClick = { hz = it; info = Tuner.highRefreshInfo(it).message }) { Text("$it") } } }; Text("Modos detectados: ${telemetry.supportedHz.joinToString { "%.0f".format(it) }} Hz. Solicitar uma taxa não cria suporte físico nem remove limite interno do jogo.", color = Color.LightGray) }; Section("Conforto térmico") { Button(onClick = { val r = Tuner.setBrightness(context, 45); info = r.message }, modifier = Modifier.fillMaxWidth()) { Text("Ativar brilho econômico (45%)") } } }
                    "Perfis" -> { Section("Perfis de jogos") { profiles.sortedWith(compareByDescending<GameProfile> { if (sortFavorites) it.favorite else false }.thenByDescending { it.lastUsed }).forEach { p -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text((if (p.favorite) "★ " else "") + p.name, color = Color.White); Text("${p.category} • DPI ${p.dpi} • ${p.refreshHz} Hz", color = Color.LightGray) }; TextButton(onClick = { selected = p.copy(lastUsed = System.currentTimeMillis()); profiles = profiles.map { if (it.name == p.name) selected else it }; dpi = p.dpi.toFloat(); hz = p.refreshHz; selectedNameEdit = p.name; profilePackageEdit = p.packageName; profileDpiEdit = p.dpi.toString(); profileHzEdit = p.refreshHz.toString(); info = "Perfil ${p.name} selecionado." }) { Text("Ativar") }; TextButton(onClick = { profiles = profiles.map { if (it.name == p.name) it.copy(favorite = !it.favorite) else it } }) { Text(if (p.favorite) "★" else "☆") }; TextButton(onClick = { profiles = profiles + p.copy(name = "${p.name} cópia", favorite = false, lastUsed = 0L) }) { Text("Duplicar") } } }; OutlinedButton(onClick = { sortFavorites = !sortFavorites }, modifier = Modifier.fillMaxWidth()) { Text(if (sortFavorites) "Ordenação: favoritos primeiro" else "Ordenação: perfis padrão") }; OutlinedTextField(profileNameEdit, { profileNameEdit = it }, label = { Text("Nome para novo perfil") }, modifier = Modifier.fillMaxWidth()); OutlinedButton(onClick = { profiles = profiles + GameProfile(profileNameEdit.ifBlank { "Meu perfil ${profiles.size+1}" }, "Personalizado", dpi.toInt(), hz, "Perfil criado no aparelho"); profileNameEdit = ""; info = "Novo perfil criado." }, modifier = Modifier.fillMaxWidth()) { Text("＋ Criar perfil") }; OutlinedTextField(selectedNameEdit, { selectedNameEdit = it }, label = { Text("Nome do perfil selecionado") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(profilePackageEdit, { profilePackageEdit = it }, label = { Text("Pacote do jogo (opcional)") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(profileDpiEdit, { profileDpiEdit = it.filter(Char::isDigit).take(3) }, label = { Text("DPI") }, modifier = Modifier.weight(1f)); OutlinedTextField(profileHzEdit, { profileHzEdit = it.filter(Char::isDigit).take(3) }, label = { Text("Hz") }, modifier = Modifier.weight(1f)) }
                    OutlinedButton(onClick = { val oldName = selected.name; val updated = selected.copy(name = selectedNameEdit.take(60).ifBlank { oldName }, packageName = profilePackageEdit, dpi = profileDpiEdit.toIntOrNull()?.coerceIn(240,640) ?: selected.dpi, refreshHz = profileHzEdit.toIntOrNull()?.coerceIn(30,144) ?: selected.refreshHz); selected = updated; profiles = profiles.map { if (it.name == oldName) updated else it }; dpi = updated.dpi.toFloat(); hz = updated.refreshHz; info = "Perfil editado." }, modifier = Modifier.fillMaxWidth()) { Text("Salvar edição do perfil selecionado") }
                    Text("Perfil ativo: ${selected.name}", color = cyan) } }
                    "Mais" -> { Section("Ferramentas avançadas") {
                        listOf("Laboratório", "Térmico", "Sessões", "Automação", "Conforto", "Logs").forEach { destination -> OutlinedButton(onClick = { page = destination }, modifier = Modifier.fillMaxWidth()) { Text(destination) } }
                    } }
                    "Laboratório" -> LaboratoryPage(dpi.toInt(), { dpi = it.toFloat() }, hz, { hz = it }, snapshot.resolution, selected.note, { note -> selected = selected.copy(note = note); profiles = profiles.map { if (it.name == selected.name) selected else it }; info = "Anotações salvas no perfil." }, { w, h -> logResult(TunerExecutor.setResolution(context, w, h)) })
                    "Térmico" -> ThermalPage(telemetry.batteryC, LocalJournal.temperatures(context), { if (Settings.System.canWrite(context)) info = Tuner.setBrightness(context, 35).message else context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))) })
                    "Sessões" -> SessionsPage(context)
                    "Automação" -> AutomationPage(context, selected, {
                        LocalJournal.savePendingRestore(context, RestoreSnapshot(snapshot.resolution, snapshot.density, telemetry.refreshHz))
                        logResult(TunerExecutor.setDpi(context, selected.dpi)); TunerExecutor.setRefresh(context, selected.refreshHz).forEach { logResult(it) }
                    }, {
                        val original = LocalJournal.pendingRestore(context) ?: RestoreSnapshot(snapshot.resolution, snapshot.density, telemetry.refreshHz)
                        val dims = Regex("(\\d+)\\s*[×x]\\s*(\\d+)").find(original.resolution)
                        val results = mutableListOf<TunerExecutor.Result>()
                        if (dims != null) results.add(TunerExecutor.setResolution(context, dims.groupValues[1].toInt(), dims.groupValues[2].toInt())) else results.add(TunerExecutor.resetResolution(context))
                        results.add(TunerExecutor.setDpi(context, original.density)); results.addAll(TunerExecutor.setRefresh(context, original.refreshHz.toInt().coerceIn(30,144)))
                        results.forEach { logResult(it) }
                        if (results.all { it.success }) LocalJournal.savePendingRestore(context, null)
                    })
                    "Conforto" -> ComfortPage({ if (Settings.System.canWrite(context)) info = Tuner.setBrightness(context, 35).message else context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))) }, {
                        TunerExecutor.resetResolution(context).also { logResult(it) }; TunerExecutor.resetDpi(context).also { logResult(it) }
                        runCatching { context.stopService(Intent(context, FloatingHudService::class.java)) }
                        LocalJournal.savePendingRestore(context, null); info = "Modo Stealth: reset solicitado e HUD fechado."
                    })
                    "Logs" -> LogsPage(commandLog)
                    else -> { Section("Device Inspector") { Text("${snapshot.model}"); Text(snapshot.android); Text("Resolução: ${snapshot.resolution}"); Text("Densidade padrão: ${snapshot.density} dpi"); Text("Modos de tela: ${snapshot.refreshRates} Hz"); Text("RAM usada/total: ${snapshot.ram}"); Text("Armazenamento: ${snapshot.storage}"); Text("Temperatura da bateria: ${snapshot.batteryC}"); Text("RAM: ${telemetry.ramAvailableMb} MB disponíveis / ${telemetry.ramTotalMb} MB"); Text("Hz atual: ${telemetry.refreshHz}"); Text("Limites reais: ${telemetry.supportedHz.joinToString { "%.0f".format(it) }} Hz detectados. O FPS interno de outro jogo não é exposto por APIs públicas comuns; RAM/temperatura são métricas do aparelho, não do processo do jogo.", color = Color.LightGray, fontSize = 12.sp); Button(onClick = { snapshot = DeviceInspector.read(context); telemetry = TelemetryRepository.read(context); info = "Diagnóstico atualizado." }, modifier = Modifier.fillMaxWidth()) { Text("Atualizar diagnóstico") }; Button(onClick = { if (Settings.canDrawOverlays(context)) context.startService(Intent(context,FloatingHudService::class.java)) else context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }, modifier = Modifier.fillMaxWidth()) { Text("Ativar HUD flutuante") } } }
                } }
                item { Section("Status / histórico") { Text(info, color = cyan); Text("As ações não suportadas são identificadas em vez de simuladas como sucesso.", color = Color.LightGray, fontSize = 12.sp) } }
                item { Section("Perfis JSON • Exportar / Importar") {
                    OutlinedButton(onClick = { jsonText = ProfileJson.export(profiles); val clip = android.content.ClipData.newPlainText("ApexPulse profiles",jsonText); (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip); info = "JSON copiado para a área de transferência." }, modifier = Modifier.fillMaxWidth()) { Text("Exportar e copiar JSON") }
                    OutlinedTextField(value=jsonText,onValueChange={jsonText=it},label={Text("Cole aqui o JSON dos perfis")},modifier=Modifier.fillMaxWidth(),minLines=3)
                    Button(onClick={ runCatching { profiles=ProfileJson.import(jsonText); selected=profiles.first(); info="${profiles.size} perfis importados." }.onFailure { info="JSON inválido: ${it.message}" } },modifier=Modifier.fillMaxWidth()) { Text("Importar perfis") }
                    OutlinedButton(onClick = { val snap = DeviceInspector.read(context); val raw = SnapshotJson.export(RestoreSnapshot(snap.resolution, snap.density, telemetry.refreshHz), ProfileJson.export(profiles)); jsonText = raw; (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("ApexPulse snapshot", raw)); info = "Snapshot completo copiado." }, modifier = Modifier.fillMaxWidth()) { Text("Exportar snapshot do aparelho + perfis") }
                    OutlinedButton(onClick = { runCatching { val pair = SnapshotJson.import(jsonText); profiles = pair.second; selected = profiles.first(); val dims = Regex("(\\d+)\\s*[×x]\\s*(\\d+)").find(pair.first.resolution); if (dims != null) logResult(TunerExecutor.setResolution(context, dims.groupValues[1].toInt(), dims.groupValues[2].toInt())); logResult(TunerExecutor.setDpi(context, pair.first.density)); TunerExecutor.setRefresh(context, pair.first.refreshHz.toInt()).forEach { logResult(it) }; info = "Snapshot importado; comandos enviados." }.onFailure { info = "Snapshot inválido: ${it.message}" } }, modifier = Modifier.fillMaxWidth()) { Text("Importar e aplicar snapshot") }
                } }
                item { Section("Histórico de execução") { if(commandLog.isEmpty()) Text("Nenhuma ação executada.",color=Color.LightGray) else commandLog.forEach { Text(it,color=Color.LightGray,fontSize=11.sp) } } }
                item { Text("ApexPulse Tuner 1.2.0 • Módulos locais e comandos auditáveis", color = Color.Gray, fontSize = 11.sp) }
            }
        }
    }
}

@Composable fun Section(title: String, content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp), content = content) }; Text(title, color = purple, fontSize = 13.sp) }
