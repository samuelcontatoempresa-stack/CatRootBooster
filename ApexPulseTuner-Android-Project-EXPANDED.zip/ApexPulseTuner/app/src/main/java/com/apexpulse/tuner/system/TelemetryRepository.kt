package com.apexpulse.tuner.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.StatFs
import android.view.WindowManager
import android.os.Build

data class TelemetrySnapshot(val ramTotalMb: Long, val ramAvailableMb: Long, val ramUsedMb: Long, val batteryC: Float?, val refreshHz: Float, val supportedHz: List<Float>, val storageFreeGb: Double)
object TelemetryRepository {
    fun read(context: Context): TelemetrySnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val modes = if (Build.VERSION.SDK_INT >= 23) display.supportedModes.map { it.refreshRate }.distinct().sorted() else listOf(display.refreshRate)
        val stat = StatFs(context.filesDir.absolutePath)
        val free = stat.availableBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        return TelemetrySnapshot(mi.totalMem / 1048576, mi.availMem / 1048576, (mi.totalMem-mi.availMem).coerceAtLeast(0) / 1048576, if (battery >= 0) battery / 10f else null, display.refreshRate, modes, free)
    }
}
