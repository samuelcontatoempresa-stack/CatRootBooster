package com.apexpulse.tuner.system

import android.content.Context
import android.app.ActivityManager
import android.os.BatteryManager
import android.os.Build
import android.os.StatFs
import android.view.WindowManager
import java.io.File

 data class DeviceSnapshot(val model: String, val android: String, val resolution: String, val density: Int, val refreshRates: String, val ram: String, val storage: String, val batteryC: String)

object DeviceInspector {
    fun read(context: Context): DeviceSnapshot {
        val metrics = context.resources.displayMetrics
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val modes = if (Build.VERSION.SDK_INT >= 23) wm.defaultDisplay.supportedModes.map { it.refreshRate.toInt() }.distinct().sorted().joinToString(", ") else "Indisponível"
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val stat = StatFs(context.filesDir.absolutePath)
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val temp = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return DeviceSnapshot("${Build.MANUFACTURER} ${Build.MODEL}", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", "${metrics.widthPixels} × ${metrics.heightPixels}", metrics.densityDpi, modes, "${(mi.totalMem-mi.availMem)/1024/1024} / ${mi.totalMem/1024/1024} MB", "${stat.availableBytes/1024/1024/1024} GB livres", if (temp >= 0) "${temp/10.0} °C" else "Indisponível")
    }
}
