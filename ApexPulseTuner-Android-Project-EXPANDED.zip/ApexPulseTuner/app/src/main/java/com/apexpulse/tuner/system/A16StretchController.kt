package com.apexpulse.tuner.system

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.apexpulse.tuner.data.LocalJournal
import com.apexpulse.tuner.data.RestoreSnapshot

/** Applies a temporary display override and automatically restores it unless confirmed. */
class A16StretchController(private val context: Context, private val scope: CoroutineScope, private val onTick: (Int) -> Unit, private val onResult: (String) -> Unit) {
    private var rollbackJob: Job? = null

    fun apply(width: Int = 1080, height: Int = 1920, density: Int = 420) {
        if (width !in 720..1440 || height !in 1280..2800 || density !in 240..640) { onResult("Valores fora da faixa segura."); return }
        rollbackJob?.cancel()
        val original = DeviceInspector.read(context)
        LocalJournal.savePendingRestore(context, RestoreSnapshot(original.resolution, original.density, TelemetryRepository.read(context).refreshHz))
        val r1 = TunerExecutor.setResolution(context, width, height)
        val r2 = TunerExecutor.setDpi(context, density)
        if (!r1.success || !r2.success) {
            if (!r1.success && !r2.success) LocalJournal.savePendingRestore(context, null) else restore()
            onResult("Não foi possível aplicar. ${r1.summary} ${r2.summary}"); return
        }
        onResult("Aplicado temporariamente. Confirme em até 10 segundos para manter.")
        rollbackJob = scope.launch {
            for (s in 10 downTo 1) { onTick(s); delay(1000) }
            restore(); onTick(0); onResult("Tempo expirado: resolução e DPI foram restauradas.")
        }
    }
    fun keep() { rollbackJob?.cancel(); rollbackJob = null; LocalJournal.savePendingRestore(context, null); onTick(0); onResult("Ajuste mantido pelo usuário. Use Restaurar para voltar ao padrão.") }
    fun restore() {
        rollbackJob?.cancel(); rollbackJob = null
        val pending = LocalJournal.pendingRestore(context)
        val dims = pending?.let { Regex("(\\d+)\\s*[×x]\\s*(\\d+)").find(it.resolution) }
        val r1 = if (dims != null) TunerExecutor.setResolution(context, dims.groupValues[1].toInt(), dims.groupValues[2].toInt()) else TunerExecutor.resetResolution(context)
        val r2 = if (pending != null && pending.density in 240..640) TunerExecutor.setDpi(context, pending.density) else TunerExecutor.resetDpi(context)
        val r3 = pending?.let { TunerExecutor.setRefresh(context, it.refreshHz.toInt().coerceIn(30,144)) } ?: emptyList()
        if (r1.success && r2.success && r3.all { it.success }) LocalJournal.savePendingRestore(context, null)
        onTick(0); onResult("Restauração solicitada. ${r1.summary} ${r2.summary} ${r3.joinToString { it.summary }}")
    }
}
