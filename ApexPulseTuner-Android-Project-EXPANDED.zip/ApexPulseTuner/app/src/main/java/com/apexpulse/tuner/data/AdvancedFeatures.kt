package com.apexpulse.tuner.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Dados locais de sessão; não coleta dados de rede nem de outros aplicativos. */
data class GameSession(
    val game: String,
    val durationMinutes: Int,
    val startTempC: Float?,
    val maxTempC: Float?,
    val profile: String,
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class RestoreSnapshot(
    val resolution: String,
    val density: Int,
    val refreshHz: Float,
    val capturedAt: Long = System.currentTimeMillis()
)

object LocalJournal {
    private const val PREFS = "apexpulse_local_journal"
    private const val SESSIONS = "sessions"
    private const val TEMPS = "temperature_samples"

    fun addSession(context: Context, session: GameSession) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(SESSIONS, "[]")) }.getOrDefault(JSONArray())
        arr.put(JSONObject().apply {
            put("game", session.game); put("durationMinutes", session.durationMinutes)
            put("startTempC", session.startTempC ?: JSONObject.NULL); put("maxTempC", session.maxTempC ?: JSONObject.NULL)
            put("profile", session.profile); put("note", session.note); put("timestamp", session.timestamp)
        })
        while (arr.length() > 100) arr.remove(0)
        prefs.edit().putString(SESSIONS, arr.toString()).apply()
    }

    fun sessions(context: Context): List<GameSession> {
        val arr = runCatching { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(SESSIONS, "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i -> runCatching {
            val o = arr.getJSONObject(i)
            GameSession(o.optString("game"), o.optInt("durationMinutes"), if (o.isNull("startTempC")) null else o.optDouble("startTempC").toFloat(), if (o.isNull("maxTempC")) null else o.optDouble("maxTempC").toFloat(), o.optString("profile"), o.optString("note"), o.optLong("timestamp"))
        }.getOrNull() }
    }

    fun addTemperature(context: Context, temp: Float?) {
        if (temp == null) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(TEMPS, "[]")) }.getOrDefault(JSONArray())
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("c", temp))
        while (arr.length() > 240) arr.remove(0)
        prefs.edit().putString(TEMPS, arr.toString()).apply()
    }

    fun temperatures(context: Context): List<Float> {
        val arr = runCatching { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TEMPS, "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.optDouble("c")?.toFloat() }
    }

    fun savePendingRestore(context: Context, snapshot: RestoreSnapshot?) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (snapshot == null) prefs.edit().remove("pending_restore").apply() else prefs.edit().putString("pending_restore", JSONObject().put("resolution", snapshot.resolution).put("density", snapshot.density).put("refreshHz", snapshot.refreshHz).put("capturedAt", snapshot.capturedAt).toString()).apply()
    }

    fun pendingRestore(context: Context): RestoreSnapshot? = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("pending_restore", null) ?: return null
        val o = JSONObject(raw)
        RestoreSnapshot(o.optString("resolution", ""), o.optInt("density", 0), o.optDouble("refreshHz", 0.0).toFloat(), o.optLong("capturedAt"))
    }.getOrNull()
}

object SensitivityLab {
    /** Escala linear de referência; o jogo pode usar curvas ou limites próprios. */
    fun convert(value: Float, oldDpi: Int, newDpi: Int): Float {
        if (oldDpi <= 0 || newDpi <= 0) return value.coerceIn(0f, 200f)
        return (value * oldDpi.toFloat() / newDpi.toFloat()).coerceIn(0f, 200f)
    }
}

object SnapshotJson {
    fun export(snapshot: RestoreSnapshot, profilesJson: String): String = JSONObject().apply {
        put("format", "ApexPulseDeviceSnapshot"); put("version", 1)
        put("resolution", snapshot.resolution); put("density", snapshot.density); put("refreshHz", snapshot.refreshHz)
        put("capturedAt", snapshot.capturedAt); put("profiles", JSONArray(profilesJson))
    }.toString(2)

    fun import(json: String): Pair<RestoreSnapshot, List<GameProfile>> {
        val o = JSONObject(json)
        require(o.optString("format") == "ApexPulseDeviceSnapshot") { "Formato de snapshot desconhecido." }
        val resolution = o.optString("resolution")
        require(Regex("[0-9]{3,4}\\s*[×x]\\s*[0-9]{3,4}").matches(resolution)) { "Resolução inválida." }
        val density = o.optInt("density")
        require(density in 240..640) { "DPI fora do intervalo permitido." }
        val hz = o.optDouble("refreshHz", 60.0).toFloat().coerceIn(30f, 144f)
        val profiles = ProfileJson.import(o.optJSONArray("profiles")?.toString() ?: "[]")
        return RestoreSnapshot(resolution, density, hz, o.optLong("capturedAt")) to profiles
    }
}
