package com.apexpulse.tuner.data

data class GameProfile(val name: String, val category: String, val dpi: Int, val refreshHz: Int, val note: String, val packageName: String = "", val favorite: Boolean = false, val lastUsed: Long = 0L)
val defaultProfiles = listOf(
    GameProfile("Free Fire Competitivo", "Battle Royale", 420, 60, "Perfil conservador; respeita os limites do painel e do jogo."),
    GameProfile("Battle Royale", "Battle Royale", 420, 60, "Equilíbrio entre legibilidade e resposta."),
    GameProfile("FPS", "FPS", 420, 60, "Prioriza estabilidade."),
    GameProfile("MOBA", "MOBA", 420, 60, "Interface confortável."),
    GameProfile("Corrida", "Corrida", 420, 60, "Perfil geral para jogos de corrida."),
    GameProfile("Modo Equilibrado", "Sistema", 400, 60, "Equilíbrio entre legibilidade e consumo."),
    GameProfile("Economia Extrema", "Sistema", 360, 60, "Prioriza consumo moderado; não força encerramento de apps."),
    GameProfile("Alta Taxa / Resposta", "Sistema", 420, 120, "Solicita taxa alta somente se o painel suportar."),
    GameProfile("Teste de Estabilidade", "Diagnóstico", 400, 60, "Configuração conservadora para comparar estabilidade.")
)
